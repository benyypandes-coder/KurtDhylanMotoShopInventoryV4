using KurtDhylanMotoShopInventory.Models;
using KurtDhylanMotoShopInventory.Services;
using System.Text;

namespace KurtDhylanMotoShopInventory.Pages;

public class OrderPage : ContentPage
{
    readonly InventoryStore _store;
    readonly VerticalStackLayout _cartList = new() { Spacing = 8 };
    readonly Label _total = new();
    readonly List<CartItem> _cart = new();

    public OrderPage(InventoryStore store)
    {
        _store = store;
        Title = "Order / Payment";
        BackgroundColor = Color.FromArgb("#0D0D0F");

        var add = new Button { Text = "+ ADD PRODUCT TO ORDER", BackgroundColor = Color.FromArgb("#E50914"), TextColor = Colors.White, CornerRadius = 12, HeightRequest = 48 };
        add.Clicked += async (_, _) => await AddToCart();

        var checkout = new Button { Text = "CHECK OUT → RECEIPT", BackgroundColor = Color.FromArgb("#FFFFFF"), TextColor = Color.FromArgb("#111111"), CornerRadius = 12, HeightRequest = 52, FontAttributes = FontAttributes.Bold };
        checkout.Clicked += async (_, _) => await Checkout();

        _total.Text = "TOTAL AMOUNT: ₱0.00";
        _total.TextColor = Colors.White;
        _total.FontAttributes = FontAttributes.Bold;
        _total.FontSize = 18;

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = 16,
                Spacing = 12,
                Children =
                {
                    new Label { Text = "ORDER / PAYMENT", TextColor = Colors.White, FontSize = 24, FontAttributes = FontAttributes.Bold },
                    add,
                    _cartList,
                    _total,
                    checkout
                }
            }
        };
        Render();
    }

    async Task AddToCart()
    {
        var products = await _store.LoadProductsAsync();
        if (products.Count == 0)
        {
            await DisplayAlert("No products", "Add products first.", "OK");
            return;
        }

        var names = products.Select(p => p.Name).ToArray();
        var selected = await DisplayActionSheet("Select product", "Cancel", null, names);
        if (selected == null || selected == "Cancel") return;

        var p = products.First(x => x.Name == selected);
        if (p.Stock <= 0) { await DisplayAlert("Out of stock", "This product has no stock.", "OK"); return; }

        var qtyText = await DisplayPromptAsync("Quantity", $"How many? Available: {p.Stock}", initialValue: "1");
        if (!int.TryParse(qtyText, out var qty) || qty <= 0 || qty > p.Stock)
        {
            await DisplayAlert("Invalid quantity", "Enter a valid quantity within available stock.", "OK");
            return;
        }

        var existing = _cart.FirstOrDefault(x => x.ProductId == p.Id);
        if (existing == null)
            _cart.Add(new CartItem { ProductId = p.Id, Name = p.Name, Details = $"{p.Brand} {p.Model}", UnitPrice = p.Price, Quantity = qty });
        else
            existing.Quantity = Math.Min(existing.Quantity + qty, p.Stock);

        Render();
    }

    void Render()
    {
        _cartList.Clear();
        foreach (var item in _cart)
        {
            var row = new Border
            {
                BackgroundColor = Color.FromArgb("#17171A"),
                Stroke = Color.FromArgb("#303036"),
                StrokeShape = new RoundRectangle { CornerRadius = 14 },
                Padding = 12,
                Content = new HorizontalStackLayout
                {
                    Spacing = 8,
                    Children =
                    {
                        new VerticalStackLayout
                        {
                            HorizontalOptions = LayoutOptions.StartAndExpand,
                            Children =
                            {
                                new Label { Text = item.Name, TextColor = Colors.White, FontAttributes = FontAttributes.Bold },
                                new Label { Text = $"{item.Details} • Qty {item.Quantity}", TextColor = Color.FromArgb("#A9A9B0"), FontSize = 11 }
                            }
                        },
                        new Label { Text = $"₱{item.Amount:N2}", TextColor = Color.FromArgb("#E50914"), FontAttributes = FontAttributes.Bold }
                    }
                }
            };
            _cartList.Add(row);
        }
        _total.Text = $"TOTAL AMOUNT: ₱{_cart.Sum(x => x.Amount):N2}";
    }

    async Task Checkout()
    {
        if (_cart.Count == 0) { await DisplayAlert("Empty order", "Add a product first.", "OK"); return; }

        var total = _cart.Sum(x => x.Amount);
        var customer = await DisplayPromptAsync("Checkout", "Customer name:", initialValue: "Walk-in Customer");
        if (string.IsNullOrWhiteSpace(customer)) return;

        var paymentText = await DisplayPromptAsync("Payment", $"Total: ₱{total:N2}\nEnter payment amount (₱):");
        if (!decimal.TryParse(paymentText, out var payment) || payment < total)
        {
            await DisplayAlert("Invalid payment", "Payment must be equal to or greater than the total.", "OK");
            return;
        }

        var change = payment - total;
        var products = await _store.LoadProductsAsync();

        foreach (var item in _cart)
        {
            var p = products.FirstOrDefault(x => x.Id == item.ProductId);
            if (p != null) p.Stock -= item.Quantity;
        }
        await _store.SaveProductsAsync(products);

        var sb = new StringBuilder();
        sb.AppendLine("KURT DHYLAN MOTO SHOP");
        sb.AppendLine("RIDE • BUILD • TRUST");
        sb.AppendLine(new string('-', 34));
        sb.AppendLine($"CUSTOMER: {customer}");
        sb.AppendLine($"DATE: {DateTime.Now:yyyy-MM-dd HH:mm}");
        sb.AppendLine();
        foreach (var item in _cart)
            sb.AppendLine($"{item.Name} x{item.Quantity}  ₱{item.Amount:N2}");
        sb.AppendLine(new string('-', 34));
        sb.AppendLine($"TOTAL:   ₱{total:N2}");
        sb.AppendLine($"PAYMENT: ₱{payment:N2}");
        sb.AppendLine($"CHANGE:  ₱{change:N2}");

        await DisplayAlert("RECEIPT", sb.ToString(), "DONE");
        _cart.Clear();
        Render();
    }
}
