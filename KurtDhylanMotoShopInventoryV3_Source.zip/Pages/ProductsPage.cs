using KurtDhylanMotoShopInventory.Models;
using KurtDhylanMotoShopInventory.Services;

namespace KurtDhylanMotoShopInventory.Pages;

public class ProductsPage : ContentPage
{
    readonly InventoryStore _store;
    readonly VerticalStackLayout _list = new() { Spacing = 10 };
    readonly SearchBar _search = new() { Placeholder = "Search product, brand or model..." };
    List<Product> _products = new();

    public ProductsPage(InventoryStore store)
    {
        _store = store;
        Title = "Products";
        BackgroundColor = Color.FromArgb("#0D0D0F");

        var add = new Button
        {
            Text = "+ ADD PRODUCT",
            BackgroundColor = Color.FromArgb("#E50914"),
            TextColor = Colors.White,
            CornerRadius = 12,
            HeightRequest = 48
        };
        add.Clicked += async (_, _) => await AddProduct();

        _search.TextChanged += (_, _) => Render(_search.Text);

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = 16,
                Spacing = 12,
                Children =
                {
                    add,
                    _search,
                    _list
                }
            }
        };

        Appearing += async (_, _) =>
        {
            _products = await _store.LoadProductsAsync();
            Render(_search.Text);
        };
    }

    void Render(string? query)
    {
        _list.Clear();
        var q = query?.Trim().ToLowerInvariant() ?? "";
        var filtered = _products.Where(p =>
            string.IsNullOrWhiteSpace(q) ||
            p.Name.ToLowerInvariant().Contains(q) ||
            p.Brand.ToLowerInvariant().Contains(q) ||
            p.Model.ToLowerInvariant().Contains(q)).ToList();

        foreach (var p in filtered)
            _list.Add(ProductCard(p));
        if (filtered.Count == 0)
            _list.Add(new Label { Text = "No products found.", TextColor = Color.FromArgb("#A9A9B0"), HorizontalTextAlignment = TextAlignment.Center });
    }

    View ProductCard(Product p)
    {
        var stockText = p.Stock <= 0 ? "OUT OF STOCK" : $"STOCK: {p.Stock}";
        var card = new Border
        {
            BackgroundColor = Color.FromArgb("#17171A"),
            Stroke = Color.FromArgb("#303036"),
            StrokeShape = new RoundRectangle { CornerRadius = 16 },
            Padding = 14,
            Content = new Grid
            {
                ColumnDefinitions =
                {
                    new ColumnDefinition(GridLength.Star),
                    new ColumnDefinition(GridLength.Auto)
                },
                Children =
                {
                    new VerticalStackLayout
                    {
                        Spacing = 3,
                        Children =
                        {
                            new Label { Text = p.Name, TextColor = Colors.White, FontSize = 17, FontAttributes = FontAttributes.Bold },
                            new Label { Text = $"{p.Brand} • {p.Model}", TextColor = Color.FromArgb("#A9A9B0"), FontSize = 12 },
                            new Label { Text = $"₱{p.Price:N2}", TextColor = Color.FromArgb("#E50914"), FontSize = 17, FontAttributes = FontAttributes.Bold },
                            new Label { Text = stockText, TextColor = p.Stock > 0 ? Colors.LightGreen : Colors.OrangeRed, FontSize = 11 }
                        }
                    },
                    new Button { Text = "⋮", BackgroundColor = Colors.Transparent, TextColor = Colors.White, FontSize = 24 }
                }
            }
        };

        var grid = (Grid)card.Content;
        var menu = (Button)grid.Children[1];
        menu.Clicked += async (_, _) =>
        {
            var choice = await DisplayActionSheet(p.Name, "Cancel", null, "Edit", "Delete");
            if (choice == "Edit") await EditProduct(p);
            if (choice == "Delete")
            {
                _products.Remove(p);
                await _store.SaveProductsAsync(_products);
                Render(_search.Text);
            }
        };
        return card;
    }

    async Task AddProduct(Product? existing = null)
    {
        var isEdit = existing != null;
        var name = await DisplayPromptAsync(isEdit ? "Edit Product" : "Add Product", "Product name:", initialValue: existing?.Name ?? "");
        if (string.IsNullOrWhiteSpace(name)) return;

        var brand = await DisplayPromptAsync("Product", "Brand:", initialValue: existing?.Brand ?? "");
        if (brand == null) return;
        var model = await DisplayPromptAsync("Product", "Model:", initialValue: existing?.Model ?? "");
        if (model == null) return;

        var priceText = await DisplayPromptAsync("Product", "Price (₱):", initialValue: existing?.Price.ToString("0.00") ?? "");
        if (!decimal.TryParse(priceText, out var price) || price < 0)
        {
            await DisplayAlert("Invalid price", "Please enter a valid number.", "OK");
            return;
        }

        var stockText = await DisplayPromptAsync("Product", "Stocks:", initialValue: existing?.Stock.ToString() ?? "0");
        if (!int.TryParse(stockText, out var stock) || stock < 0)
        {
            await DisplayAlert("Invalid stock", "Please enter a whole number.", "OK");
            return;
        }

        if (existing == null)
            _products.Add(new Product { Name = name, Brand = brand, Model = model, Price = price, Stock = stock });
        else
        {
            existing.Name = name; existing.Brand = brand; existing.Model = model;
            existing.Price = price; existing.Stock = stock;
        }

        await _store.SaveProductsAsync(_products);
        Render(_search.Text);
    }

    Task EditProduct(Product p) => AddProduct(p);
}
