# Kurt Dhylan Moto Shop Inventory

Android inventory/order app built with .NET MAUI (.NET 10).

## Included functions

- Products: add/edit/delete
  - Name
  - Brand
  - Model
  - Price
  - Stocks
- Services / Labor: add/edit/delete
  - Labor name
  - Price
- Search products by name, brand, model
- Search services
- Combined inventory search
- Create order / cart
- Quantity validation against stock
- Payment and automatic change calculation
- Receipt screen
- Stock is automatically reduced after successful checkout
- Local JSON storage in the app's data folder, so products remain after closing/reopening the app
- Red/black racing-style UI inspired by the supplied shop icon
- GitHub Actions workflow to build an APK

## Build locally

```bash
dotnet workload install maui-android
dotnet restore
dotnet publish KurtDhylanMotoShopInventory.csproj -f net10.0-android -c Release -p:AndroidPackageFormat=apk
```

The APK will be under `bin/Release/net10.0-android/`.

## GitHub

Push the project to GitHub. The workflow at `.github/workflows/build-android.yml` can be started from:

Actions → Build Kurt Dhylan Moto Shop Inventory → Run workflow

The resulting APK is uploaded as a GitHub Actions artifact.

## Important

This version stores inventory locally on each device. It does not yet have a cloud database or multi-device synchronization. That can be added later without changing the basic UI flow.
