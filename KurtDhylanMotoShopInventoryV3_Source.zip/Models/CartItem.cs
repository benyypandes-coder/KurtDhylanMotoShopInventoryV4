namespace KurtDhylanMotoShopInventory.Models;

public class CartItem
{
    public Guid ProductId { get; set; }
    public string Name { get; set; } = "";
    public string Details { get; set; } = "";
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
    public decimal Amount => UnitPrice * Quantity;
}
