namespace KurtDhylanMotoShopInventory;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        MainPage = new NavigationPage(new Pages.HomePage())
        {
            BarBackgroundColor = Color.FromArgb("#0D0D0F"),
            BarTextColor = Colors.White
        };
    }
}
